# main.py
from search import SearchSim

if __name__ == "__main__":
    SearchSim().run()
